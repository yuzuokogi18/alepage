import Cart from "../molecules/Cart";

function Section3() {
    return (
    <>
        <Cart></Cart>  
    </>)
}

export default Section3;