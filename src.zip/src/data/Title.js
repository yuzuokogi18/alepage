const Title = {
    products : [
        {
            text: 'Mi Amigo el Dragon'
            
        }
    ]
}

export default Title;