const movies = [
    {
        title: "Oakes Fegley como Pete.",
        image: "personajes.jpeg"
    },
    {
        title: "Bryce Dallas Howard como Grace.",
        image: "R.jpeg"
    },
    {
        title: "Robert Redford como el padre de Grace.",
        image: "OIP (1).jpeg"
    },
    {
        title: "Wes Bentley como Jack.",
        image: "person.jpg"
    },
    {
        title: "Karl Urban como Gavin.",
        image: "OIP (2).jpeg"
    }
];

export default movies;
