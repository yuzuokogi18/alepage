export const descriptionData = {
    text: "Grace, una guarda forestal cuyo padre solía contarle de pequeña, a ella y a los otros muchachos, la historia de un fiero dragón que habita en la región, investiga la historia de Peter, un niño huérfano que acaba de aparecer de la nada y asegura vivir en el bosque con un dragón verde llamado Eliott. Natalie, una niña de 11 años, hija del dueño de la serrería local, ayuda a Grace a desentrañar este misterio.Duración: 1h 43m.",
    image: "xdd.jpeg"
  };
  