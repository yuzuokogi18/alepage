import Home from "./Pages/Home"





function App() {

  return (<Home></Home>)
}

export default App
